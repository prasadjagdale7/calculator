# React Native Calculator

This is a react-native calculator with the feature of light and dark theme. We can toggle between both the themes with just one click.
You can checkout the entire tutorial on the making of this amazing Calculator  [Here](https://youtu.be/6Q2LVOZbDaw)

### Screens

| ![](assets/images/Screenshot.png) | ![](assets/images/Screenshot-1.png) |
| :-------------: | :-------------: |
